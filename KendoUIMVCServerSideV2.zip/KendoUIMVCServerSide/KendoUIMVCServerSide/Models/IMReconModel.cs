﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KendoUIMVCServerSide.Models
{
    public partial class IMReconModel
    {
        public int IMEventID { get; set; }
        public string MCIssuer { get; set; }
        public string POFullName { get; set; }
        public string POAdaptive { get; set; }
        public string CPFullName { get; set; }
        public string CPAdaptive { get; set; }
        public string InternalRiskRating { get; set; }
        public string Regime { get; set; }
        public Nullable<int> Regulator { get; set; }
        public Nullable<int> ClientType { get; set; }
        public string ContractType { get; set; }
        public string ContractName { get; set; }
        public Nullable<int> AgrCCY { get; set; }
        public Nullable<int> ReconType { get; set; }
        public bool AcadiaSoftIMEM { get; set; }
        public Nullable<bool> CPConsoleValuationAgent { get; set; }
        public Nullable<System.DateTime> EventStartDate { get; set; }
        public Nullable<System.DateTime> EventEndDate { get; set; }
        public Nullable<bool> Status { get; set; }
        public Nullable<int> SubStatus { get; set; }
        public Nullable<int> ClosureType { get; set; }
        public int Age { get; set; }
        public string DiscrepancyStatus { get; set; }
        public Nullable<System.DateTime> ReconDate { get; set; }
        public decimal BMOCallAmountAgrCCY { get; set; }
        public decimal CPCallAmountAgrCCY { get; set; }
        public decimal CPAgreedAmountAgrCCY { get; set; }
        public decimal BMOCallAmountUSD { get; set; }
        public decimal CPCallAmoutUSD { get; set; }
        public decimal CPAgreedAmountUSD { get; set; }
        public decimal UncalledAmountUSD { get; set; }
        public decimal DisputeAmountUSD { get; set; }
        public decimal DisputeAmountEUR { get; set; }
        public decimal DisputePercentage { get; set; }
        public bool ReportableDispute { get; set; }
        public decimal CollateralPositionSettledUSD { get; set; }
        public decimal CollateralPositionTransitUSD { get; set; }
        public bool TwoWayCall { get; set; }
        public Nullable<int> VPCCode { get; set; }
        public bool VPC { get; set; }
        public Nullable<int> PrimaryProductDriver { get; set; }
        public Nullable<int> CMGPrimaryDriver { get; set; }
        public string CMGComment { get; set; }
        public bool Reported { get; set; }
        public Nullable<int> Associate { get; set; }
        public string Attachments { get; set; }
        public string IMEMHyperLink { get; set; }
        public string ReviewComment { get; set; }
        public Nullable<int> ReviewStatus { get; set; }
        public Nullable<bool> Unlock { get; set; }
        public Nullable<decimal> MatchedIMExposureDiffAgrCCY { get; set; }
        public Nullable<int> MatchedTradesCout { get; set; }
        public Nullable<decimal> SIMMExposureDiffAgrCCY { get; set; }
        public Nullable<int> SIMMTradeCount { get; set; }
        public Nullable<decimal> ScheduleBasedImExposureDiffAgrCCY { get; set; }
        public Nullable<int> ScheduleBasedTradeCount { get; set; }
        public Nullable<decimal> UnmatchedIMExposureDiffAgrCCY { get; set; }
        public Nullable<int> UnmatchedBMOMissingTradesCount { get; set; }
        public Nullable<int> UnmatchedCPMissingTradesCount { get; set; }
        public Nullable<System.DateTime> ValuationDate { get; set; }
        public Nullable<bool> OutsideTolerance { get; set; }
        public string ClosingCriteria { get; set; }
        public Nullable<int> ProcessStatus { get; set; }
        public string ProcessStatusMessage { get; set; }
        public string ProcessLog { get; set; }
        public Nullable<System.DateTime> BusinessDate { get; set; }
        public Nullable<System.DateTime> DateTimeCreated { get; set; }
        public Nullable<System.DateTime> DateTimeUpdated { get; set; }
    }
}