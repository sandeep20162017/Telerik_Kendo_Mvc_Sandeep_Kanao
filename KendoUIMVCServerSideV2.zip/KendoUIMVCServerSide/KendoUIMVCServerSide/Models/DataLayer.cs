﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Data.SqlClient;

namespace KendoUIMVCServerSide.Models
{
    public class Datalayer
    {
        SqlConnection con = new SqlConnection();
        public Datalayer()
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
        }
        public void query(string sql)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            con.Open();
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        

        public List<IMReconModel> GetIMRecons()
        {
            try
            {
                DataTable dt = new DataTable();
                DataSet ds = new DataSet();
                List<IMReconModel> IMReconList = new List<IMReconModel>();
                string sql = "select * from [IMRecon]";
                SqlDataAdapter da = new SqlDataAdapter(sql, con);
                ds.Reset();
                da.Fill(ds);
                dt = ds.Tables[0];
                foreach (DataRow row in dt.Rows)
                {
                    IMReconModel imRecon = new IMReconModel();
                    imRecon.IMEventID = Convert.ToInt32(row["IMEventID"].ToString());
                    imRecon.MCIssuer = row["MCIssuer"].ToString();
                    imRecon.POFullName = row["POFullName"].ToString();
                    imRecon.POAdaptive = row["POAdaptive"].ToString();
                    imRecon.CPFullName = row["CPFullName"].ToString();
                    imRecon.CPAdaptive = row["CPAdaptive"].ToString();
                    //Add
                 


                    IMReconList.Add(imRecon);
                }
                return IMReconList;
            }
            catch (Exception ex)
            {
                var exp = ex.InnerException.ToString();
                return null;
            }
        }
    }
}