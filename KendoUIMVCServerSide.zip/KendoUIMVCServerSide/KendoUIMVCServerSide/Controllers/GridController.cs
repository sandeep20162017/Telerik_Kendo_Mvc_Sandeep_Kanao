﻿using System;
﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using KendoUIMVCServerSide.Models;

namespace KendoUIMVCServerSide.Controllers
{
	public partial class GridController : Controller
    {
		public ActionResult IMRecon_Read([DataSourceRequest]DataSourceRequest request)
		{           
            Datalayer dl = new Datalayer();
            List<IMReconModel> imReconList = dl.GetIMRecons();
            return Json(imReconList.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);          
		}

        
        public ActionResult IMRecon_Menu()
        {
            return View();
        }


    }
}
