﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using KendoUIMVCServerSide.Models;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;

namespace KendoUIMVCServerSide.Controllers
{
    public partial class GridController : Controller
    {
        
        public ActionResult Editing_Popup()
        {
            return View();
        }

        public ActionResult EditingPopup_Read([DataSourceRequest] DataSourceRequest request)
        {
            Datalayer dl = new Datalayer();
            List<IMReconModel> imReconList = dl.GetIMRecons();
            return Json(imReconList.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult EditingPopup_Create([DataSourceRequest] DataSourceRequest request, IMReconModel imRecon)
        {
           

            return null;
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult EditingPopup_Update([DataSourceRequest] DataSourceRequest request, IMReconModel imRecon)
        {
            

            return null;
        }

        

    }
}